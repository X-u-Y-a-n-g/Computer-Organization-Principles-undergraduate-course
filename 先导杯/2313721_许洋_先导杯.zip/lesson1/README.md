四个文件实现了不同方法

lesson1_sourcefile_dcu.cpp

实现了dcu加速，以及测量

lesson1_sourcefile_g.cpp

实现了openmp，block和other method加速，以及测量

lesson1_sourcefile_m.cpp

实现了mpi加速

lesson1_sourcefile_m cpoy.cpp

在实现mpi加速的过程中进行了相关测量